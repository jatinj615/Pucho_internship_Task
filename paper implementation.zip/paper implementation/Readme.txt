Worked on two papers :

    1. - http://www.gitxiv.com/posts/9bPrYT4Qvk8m5qiLF/the-wili-benchmark-dataset-for-written-language
    2. - http://www.gitxiv.com/posts/ZoyxrsoS9LfCqdA4E/lstms-for-human-activity-recognition

Code And Results :
    1. - Wili dataset for language detection : I have written the algorithm in wili/wili.py python file. Was not able to run the model for time shortage but implemented the Algorithm in the paper.
    2. - Human activity recognition : The code and results are in HAR/Human Activity Recognition.ipynb and HAR/ directory respectively using Artificial Neural Network and Recurrent Neural Network LSTM (Long Short Term Memory).

Dataset :
    1. - https://zenodo.org/record/841984#.WyNmtp9fi00
    2. - https://archive.ics.uci.edu/ml/machine-learning-databases/00240/UCI HAR Dataset.zip