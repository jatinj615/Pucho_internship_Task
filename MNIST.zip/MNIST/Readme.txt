I worked on the Kagle competition for Digit Recognition. Link for the competition - https://www.kaggle.com/c/digit-recognizer .

The Best model is in the file named as - Best Model.ipynb
In this Model I used Suppot vector Machine and Tuned it with the help of grid search. I also used Dimentionality Reduction with PCA (Principal Component Analysis) Technique so I can get a fast training as well as testing time which imroves my model's performance without Loosing any important information.

